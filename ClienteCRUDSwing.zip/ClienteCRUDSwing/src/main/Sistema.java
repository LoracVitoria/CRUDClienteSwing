package main;

import view.ClienteView;

public class Sistema {
    public static void main(String[] args){
        //System.out.println("OK");
        new ClienteView().setVisible(true);
    }
}
