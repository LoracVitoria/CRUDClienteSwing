package model;

import java.sql.*;
import java.util.ArrayList;

public class DaoCliente {
	private Connection conn;
	private Statement st;
	
	private void conectar(){
		try{
			conn = GerenciadorConexao.pegarConexao();
			st = conn.createStatement();
		}catch(ClassNotFoundException e1){
			System.out.println(e1.getMessage());
		}catch(SQLException e2){
			System.out.println(e2.getMessage());
		}
	}
	
	private void desconectar(){
		try{
			st.close();
			conn.close();
		}catch(SQLException e){
			System.out.println("Erro ao fechar a conexao: " + e.getMessage());
		}
	}
	
	public boolean inserir(Cliente v){
		boolean resultado = false;
		try{
			conectar();
			String comando = "INSERT INTO tb_clientes VALUES (NULL, '"
				+ v.getNome() + "', '" + v.getEmail() + "', '"
				+ v.getDataNascimento() + "', " + v.getTelefone() + ");";
			
			//System.out.println("SQL: " + comando);
			
			st.executeUpdate(comando);
			resultado = true;
		}catch(SQLException e){
			System.out.println("Erro ao inserir o registro: " + e.getMessage());
		}finally{
			desconectar();
		}
		return resultado;
	}

	public ArrayList<Cliente> buscarTodos(){
            ArrayList<Cliente> resultados = new ArrayList<Cliente>();
            try{
                    conectar();
                    ResultSet rs = st.executeQuery("select * from tb_clientes order by email;");
                    while(rs.next()){
                            Cliente v = new Cliente();
                            v.setCodigo(rs.getInt("codigo"));
                            v.setNome(rs.getString("nome"));
                            v.setEmail(rs.getString("email"));
                            v.setDataNascimento(rs.getString("datanascimento"));
                            v.setTelefone(rs.getLong("telefone"));

                            resultados.add(v);
                    }
            }catch(SQLException e){
                    System.out.println("Erro: " + e.getMessage());
            }finally{
                    desconectar();
            }
            return resultados;
	}	

	public ArrayList<Cliente> buscarTodosFiltro(String campo, String filtro){
            ArrayList<Cliente> resultados = new ArrayList<Cliente>();
            
            //permite pesquisar apenas por nome ou email
            if(!campo.equals("nome") && !campo.equals("email")){
                return resultados;
            }
            
            try{
                conectar();
                ResultSet rs = st.executeQuery("select * from tb_clientes "
                        + " where " + campo + " like '%" + filtro + "%'"
                        + " order by email;");
                while(rs.next()){
                        Cliente v = new Cliente();
                        v.setCodigo(rs.getInt("codigo"));
                        v.setNome(rs.getString("nome"));
                        v.setEmail(rs.getString("email"));
                        v.setDataNascimento(rs.getString("datanascimento"));
                        v.setTelefone(rs.getLong("telefone"));

                        resultados.add(v);
                }
            }catch(SQLException e){
                    System.out.println("Erro: " + e.getMessage());
            }finally{
                    desconectar();
            }
            return resultados;
	}
        
	public int excluir(int cod){
		int qtde = 0;
		try{
			conectar();
			String comando = "delete from tb_clientes where codigo = " + cod + ";";
			st.executeUpdate(comando);
			qtde = st.getUpdateCount();//mostra quantos registros foram afetados no BD
		}catch(SQLException e){
			System.out.println("Erro: " + e.getMessage());
		}finally{
			desconectar();
		}		
		return qtde;
	}

	public Cliente consultar(int cod){
		Cliente v = null;
		try{
			conectar();
			String comando = "select * from tb_clientes where codigo = " + cod + ";";
			ResultSet rs = st.executeQuery(comando);
			if(rs.next()){
				v = new Cliente();
				v.setCodigo(rs.getInt("codigo"));
				v.setNome(rs.getString("nome"));
				v.setEmail(rs.getString("email"));
				v.setDataNascimento(rs.getString("datanascimento"));
				v.setTelefone(rs.getLong("telefone"));
			}
		}catch(SQLException e){
			System.out.println("Erro: " + e.getMessage());
		}finally{
			desconectar();
		}		
		return v;		
	}

	public int alterar(Cliente v){
		int qtde = 0;
		try {
			conectar();  
			String comando = "UPDATE  tb_clientes SET nome = '" + v.getNome()
				+ "', email = '" + v.getEmail() + "', datanascimento = '" + v.getDataNascimento() 
				+ "', telefone = " + v.getTelefone() + " WHERE codigo = " + v.getCodigo() + ";";  
			st.executeUpdate(comando);  
			qtde = st.getUpdateCount();
		} catch (SQLException e) {  
			System.out.println("Erro ao atualizar:" + e.getMessage());  
		} finally {  
			desconectar();  
		}  
		return qtde;
	}		
}


